# kaiten-daily-helper
Chrome extension for auto navigation in Kaiten when making calls
