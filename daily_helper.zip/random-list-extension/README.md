# kaiten-daily-helper
Chrome extension for automatic navigation in Kaiten during meetings
